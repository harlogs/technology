document.getElementById("start").onclick = () => {
  chrome.runtime.sendMessage({ action: "open" });
};
