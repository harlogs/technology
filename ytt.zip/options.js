document.getElementById("save").onclick = () => {
  const url = document.getElementById("url").value;
  const count = parseInt(document.getElementById("count").value);

  browser.storage.local.set({ url, count }).then(() => {
    alert("Settings saved!");
  });
};

document.getElementById("open").onclick = () => {
  browser.runtime.sendMessage({ action: "open_windows" });
};