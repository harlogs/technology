browser.runtime.onMessage.addListener((msg) => {
  if (msg.action === "open_windows") {
    openWindows();
  }
});

browser.runtime.onStartup.addListener(openWindows);
browser.runtime.onInstalled.addListener(openWindows);

async function openWindows() {
  try {
    const { url, count } = await browser.storage.local.get(["url", "count"]);

    if (!url || !count) {
      console.error("Settings missing: Please set URL and number of windows.");
      return;
    }

    let delay = 0;

    for (let i = 0; i < count; i++) {
      setTimeout(async () => {
        try {
          const newWindow = await browser.windows.create({
            url,
            focused: i === 0,
            width: 300,
            height: 300,
            left: 50 + (i * 20),   // optional slight offset
            top: 50 + (i * 20)     // optional slight offset
          });

          if (!newWindow || !newWindow.tabs || !newWindow.tabs[0]) {
            console.error("Window creation returned empty");
            return;
          }

          console.log(`Window #${i + 1} created (300x300)`);

        } catch (err) {
          console.error("Error:", err);
        }
      }, delay);

      delay += 600;
    }

  } catch (err) {
    console.error("Failed to read settings:", err);
  }
}
